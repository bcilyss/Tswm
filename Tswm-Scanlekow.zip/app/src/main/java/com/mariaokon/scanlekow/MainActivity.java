package com.mariaokon.scanlekow;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanIntentResult;
import com.journeyapps.barcodescanner.ScanOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;




public class MainActivity extends AppCompatActivity {

    ListView listView;


    ArrayAdapter<String> arrayAdapter;
    //TextView mTextViewResult;
    Button btn_getId;
    Button btn_getByName;
    Button btn_scan;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn_scan = findViewById(R.id.btn_scan);
        btn_scan.setOnClickListener(v -> {
            scanCode();
        });
        listView = findViewById(R.id.listview);
        //arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, name);
        listView.setAdapter(arrayAdapter);
        btn_getId = findViewById(R.id.btn_getId);
        btn_getByName = findViewById(R.id.btn_getByName);



    }




    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu,menu);
        MenuItem menuItem = menu.findItem(R.id.action_search);
        SearchView searchView = (SearchView) menuItem.getActionView();
        searchView.setQueryHint("Nazwa lub kod leku");

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {

                //arrayAdapter.getFilter().filter(newText);

                return false;
            }
        });

        btn_getId.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RequestQueue queue = Volley.newRequestQueue(MainActivity.this);
                String url = "https://rejestrymedyczne.ezdrowie.gov.pl/api/rpl/medicinal-products/search/public?name=" + searchView.getQuery();
                JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        String commonName = "";
                        String subAkt = "";
                        String pharma = "";
                        ArrayList<String> words= new ArrayList<String>();

                        try {

                            JSONArray jsonArray = response.getJSONArray("content");
                            for (int i =0; i<jsonArray.length();i++){
                                JSONObject lek = jsonArray.getJSONObject(i);
                                commonName = lek.getString("medicinalProductName");
                                pharma = lek.getString("pharmaceuticalFormName");
                                subAkt = lek.getString("activeSubstanceName");
                                words.add(i,"Nazwa: "+ commonName + "\n"+"Substancja aktywna to: " + subAkt + ". Postać farmaceutyczna:  " + pharma);

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1,  words);
                        listView.setAdapter(arrayAdapter);
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();

                    }
                }) ;
                queue.add(jsonObjectRequest);

            }
        });


        btn_getByName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                RequestQueue queue = Volley.newRequestQueue(MainActivity.this);
                String url = "https://rejestrymedyczne.ezdrowie.gov.pl/api/rpl/medicinal-products/search/public?eanGtin=" + searchView.getQuery();
                JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        String commonName = "";
                        String subAkt = "";
                        String pharma = "";
                        String kod ;
                        ArrayList<String> words= new ArrayList<String>();

                        try {

                            JSONArray jsonArray = response.getJSONArray("content");
                            for (int i =0; i<jsonArray.length();i++){
                                JSONObject lek = jsonArray.getJSONObject(i);
                                commonName = lek.getString("medicinalProductName");
                                pharma = lek.getString("pharmaceuticalFormName");
                                subAkt = lek.getString("activeSubstanceName");
                                kod = lek.getString("gtin");
                                words.add(i,"Nazwa: "+ commonName + "\n"+"Substancja aktywna to: " + subAkt + ". Postać farmaceutyczna:  " + pharma);

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1,  words);
                        listView.setAdapter(arrayAdapter);
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();

                    }
                }) ;
                queue.add(jsonObjectRequest);
            }
        });
        return super.onCreateOptionsMenu(menu);


    }



    public void scanCode() {
        ScanOptions options = new ScanOptions();
        options.setPrompt("Przycisk głośności włączy lampę");
        options.setBeepEnabled(true);
        options.setOrientationLocked(true);
        options.setCaptureActivity(CaptureAct.class);
        barLaucher.launch(options);
        ScanIntentResult wynik;

    }
    ActivityResultLauncher<ScanOptions> barLaucher = registerForActivityResult(new ScanContract(),result -> {
        if(result.getContents() != null)
        {
            String wynik = result.getContents();
            ClipboardManager clipboard = (ClipboardManager)getApplicationContext().getSystemService(getApplicationContext().CLIPBOARD_SERVICE);
            ClipData clip = ClipData.newPlainText("",wynik);
            clipboard.setPrimaryClip(clip);
            Toast.makeText(getApplicationContext(), "Kod kreskowy skopiowano do schowka!", Toast.LENGTH_LONG).show();
            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setTitle("Wynik");
            builder.setMessage(result.getContents());
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {


                    dialogInterface.dismiss();
                }
            }).show();

        }
    });
}
